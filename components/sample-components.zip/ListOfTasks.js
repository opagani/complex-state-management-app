'use client'
import { useContext, useState } from "react"
import { TasksContext } from "@/contexts/TasksContext"
import { TaskItem } from "./TaskItem"

export function ListOfTasks({}) {
    const {filtered} = useContext(TasksContext)


    return (
        <>
            {filtered().map((task) => <TaskItem task={task} key={task.id}/>)}
        </>
    )

}
